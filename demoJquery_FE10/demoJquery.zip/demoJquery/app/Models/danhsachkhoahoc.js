function DanhSachKhoaHoc(){
    this.MangKhoaHoc = [];
}