function KhoaHoc(){
    this.MaKhoaHoc = '';
    this.TenKhoaHoc = '';
    this.MoTa = '';
    this.LuotXem = '';
    this.NguoiTao = '';
}