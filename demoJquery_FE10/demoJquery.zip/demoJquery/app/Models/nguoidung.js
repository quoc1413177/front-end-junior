function NguoiDung(tk,mk,ht,email,sodt,maloaind,tenloaind){
    this.TaiKhoan = tk;
    this.MatKhau = mk;
    this.HoTen = ht;
    this.Email = email;
    this.SoDT = sodt;
    this.MaLoaiNguoiDung = maloaind;
    this.TenLoaiNguoiDung = tenloaind;
    this.Diem = '';
}