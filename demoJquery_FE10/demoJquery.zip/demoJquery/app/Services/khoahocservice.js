function KhoaHocService(){
    this.LayDanhSachKhoaHoc = function(){
        var apiURL = `http://sv.myclass.vn/api/QuanLyTrungTam/DanhSachKhoaHoc`;
        return $.ajax({
            url:apiURL,
            type:"GET",
            dataType:"json",
            // async:false
        });
    }
}