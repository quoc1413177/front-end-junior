$(document).ready(function () {

    var dsKhoaHoc = new DanhSachKhoaHoc();
    var svKhoaHoc = new KhoaHocService();
    var svNguoiDung = new NguoiDungService();

    //Gọi phương thức từ service thông qua api đã cài đặt lấy dữ liệu

    svKhoaHoc.LayDanhSachKhoaHoc()
        .done(function (data) {
            dsKhoaHoc.MangKhoaHoc = data;
            LoadDanhSachKhoaHoc(dsKhoaHoc.MangKhoaHoc);
            console.log(dsKhoaHoc.MangKhoaHoc);
        })
        .fail(function (error) {

        });
    //Load nội dung cho thẻ select người tạo
    svNguoiDung.LayDanhSachNguoiDung().done(function (MangNguoiDung) {
        //Gọi hàm load nội dung cho thẻ select
        // console.log(MangNguoiDung);
        LoadSelectNguoiDung(MangNguoiDung);
    }).fail(function (error) {
        console.log(error);
    });

    function LoadSelectNguoiDung(MangNguoiDung) {
        var noiDungSelect = "";
        MangNguoiDung.map(function (nguoiDung, index) {
            if (nguoiDung.MaLoaiNguoiDung == "GV") {
                noiDungSelect += `
                    <option value="${nguoiDung.TaiKhoan}">${nguoiDung.HoTen}</option>
            `;
            }
        });
        $("#NguoiTao").html(noiDungSelect);
    }

    function LoadDanhSachKhoaHoc(MangKhoaHoc) {
        var noiDungTable = ``;
        //index: vị trí phần tử trong mảng
        //khoahoc: đối tượng trong mảng
        MangKhoaHoc.map(function (khoahoc, index) {
            var moTa = khoahoc.MoTa;
            if (khoahoc.MoTa != null) {
                // BieuThucDieuKien ? Đúng thực hiện BieuThuc1 : Sai thực hiện biểu thức 2
                khoahoc.MoTa.length >= 100 ? moTa = khoahoc.MoTa.substring(0, 100) : moTa = khoahoc.MoTa;
            }
            noiDungTable += `
                <tr>
                    <td></td>
                    <td>${khoahoc.MaKhoaHoc}</td>
                    <td>${khoahoc.TenKhoaHoc}</td>
                    <td>${moTa} ...</td>
                    <td><img src='${khoahoc.HinhAnh}' width="75" height="50" /></td>
                    <td>${Number(khoahoc.LuotXem).toLocaleString()}</td>
                    <td>${khoahoc.NguoiTao}</td>
                    <td><a href="chinhsuakhoahoc.html?makhoahoc=${khoahoc.MaKhoaHoc}">Chỉnh sửa</a></td>
                </tr>
            `
        });



        $("#tblDanhSachKhoaHoc").html(noiDungTable);
    }



});